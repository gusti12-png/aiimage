import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import sharp from "sharp";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Image processing endpoint
  app.post('/api/process-image', upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No image file provided' });
      }

      const { type } = req.body;
      const imageBuffer = req.file.buffer;

      let processedBuffer: Buffer;

      switch (type) {
        case 'enhance':
          processedBuffer = await sharp(imageBuffer)
            .sharpen()
            .normalize()
            .jpeg({ quality: 90 })
            .toBuffer();
          break;

        case 'remove-background':
          // For demo purposes, we'll just apply a simple threshold
          // In production, you'd use a proper background removal AI service
          processedBuffer = await sharp(imageBuffer)
            .threshold(128)
            .png()
            .toBuffer();
          break;

        case 'color-correct':
          processedBuffer = await sharp(imageBuffer)
            .modulate({
              brightness: 1.1,
              saturation: 1.2,
            })
            .jpeg({ quality: 90 })
            .toBuffer();
          break;

        case 'sharpen':
          processedBuffer = await sharp(imageBuffer)
            .sharpen(2.0)
            .jpeg({ quality: 90 })
            .toBuffer();
          break;

        default:
          return res.status(400).json({ error: 'Invalid processing type' });
      }

      // Convert processed image to base64
      const base64Image = `data:image/jpeg;base64,${processedBuffer.toString('base64')}`;

      res.json({
        success: true,
        imageUrl: base64Image,
        processingType: type,
      });

    } catch (error) {
      console.error('Image processing error:', error);
      res.status(500).json({ 
        error: 'Failed to process image',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Endpoint to apply basic filters (brightness, contrast, saturation)
  app.post('/api/apply-filters', upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No image file provided' });
      }

      const { brightness = 1, contrast = 1, saturation = 1 } = req.body;
      const imageBuffer = req.file.buffer;

      const processedBuffer = await sharp(imageBuffer)
        .modulate({
          brightness: parseFloat(brightness),
          saturation: parseFloat(saturation),
        })
        .linear(parseFloat(contrast), 0) // Simple contrast adjustment
        .jpeg({ quality: 90 })
        .toBuffer();

      const base64Image = `data:image/jpeg;base64,${processedBuffer.toString('base64')}`;

      res.json({
        success: true,
        imageUrl: base64Image,
      });

    } catch (error) {
      console.error('Filter application error:', error);
      res.status(500).json({ 
        error: 'Failed to apply filters',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
