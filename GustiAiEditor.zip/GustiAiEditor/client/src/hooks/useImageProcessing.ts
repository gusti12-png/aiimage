import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export function useImageProcessing() {
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const { toast } = useToast();

  const processWithAI = useCallback(async (type: string) => {
    if (!currentImage) {
      toast({
        title: "No Image",
        description: "Please upload an image first.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      // Convert base64 to blob for upload
      const response = await fetch(currentImage);
      const blob = await response.blob();
      
      const formData = new FormData();
      formData.append('image', blob, 'image.jpg');
      formData.append('type', type);

      const result = await apiRequest('POST', '/api/process-image', formData);
      const processedImageData = await result.json();
      
      setCurrentImage(processedImageData.imageUrl);
      
      toast({
        title: "Success!",
        description: `${type} applied successfully.`,
      });
    } catch (error) {
      toast({
        title: "Processing Failed",
        description: "There was an error processing your image. Please try again.",
        variant: "destructive",
      });
    } finally {
      // Simulate processing time for better UX
      setTimeout(() => {
        setIsProcessing(false);
      }, 1000);
    }
  }, [currentImage, toast]);

  const enhanceImage = useCallback(() => processWithAI('enhance'), [processWithAI]);
  const removeBackground = useCallback(() => processWithAI('remove-background'), [processWithAI]);
  const colorCorrect = useCallback(() => processWithAI('color-correct'), [processWithAI]);
  const sharpenImage = useCallback(() => processWithAI('sharpen'), [processWithAI]);

  const resetImage = useCallback(() => {
    if (originalImage) {
      setCurrentImage(originalImage);
      setBrightness(100);
      setContrast(100);
      setSaturation(100);
      
      toast({
        title: "Reset",
        description: "Image restored to original state.",
      });
    }
  }, [originalImage, toast]);

  const downloadImage = useCallback((format: 'jpg' | 'png' | 'webp' = 'jpg') => {
    if (!currentImage) {
      toast({
        title: "Error",
        description: "Tidak ada gambar untuk didownload.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Create download link
      const link = document.createElement('a');
      link.href = currentImage;
      link.download = `gusti-ai-edited-${Date.now()}.${format}`;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Berhasil!",
        description: `Gambar berhasil didownload dalam format ${format.toUpperCase()}.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal mendownload gambar. Silakan coba lagi.",
        variant: "destructive",
      });
    }
  }, [currentImage, toast]);

  return {
    currentImage,
    originalImage,
    setCurrentImage,
    setOriginalImage,
    isProcessing,
    brightness,
    contrast,
    saturation,
    setBrightness,
    setContrast,
    setSaturation,
    enhanceImage,
    removeBackground,
    colorCorrect,
    sharpenImage,
    resetImage,
    downloadImage,
  };
}
