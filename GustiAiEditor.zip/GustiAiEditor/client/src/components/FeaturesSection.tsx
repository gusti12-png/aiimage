export function FeaturesSection() {
  return (
    <section className="py-20 bg-slate-50" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Powerful AI Features</h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Experience the future of image editing with our advanced AI-powered tools
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {/* Feature Cards */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
              <i className="fas fa-magic text-primary text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-4">AI Enhancement</h3>
            <p className="text-slate-600">Automatically improve image quality, reduce noise, and enhance details with our advanced AI algorithms.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center mb-6">
              <i className="fas fa-cut text-secondary text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-4">Smart Background Removal</h3>
            <p className="text-slate-600">Remove backgrounds with precision using AI that understands object boundaries and complex edges.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-success/10 rounded-xl flex items-center justify-center mb-6">
              <i className="fas fa-palette text-success text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-4">Color Correction</h3>
            <p className="text-slate-600">Intelligent color balancing and correction that adapts to your image's unique characteristics.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-warning/10 rounded-xl flex items-center justify-center mb-6">
              <i className="fas fa-search-plus text-warning text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-4">Super Resolution</h3>
            <p className="text-slate-600">Upscale images without losing quality using our state-of-the-art super-resolution technology.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-error/10 rounded-xl flex items-center justify-center mb-6">
              <i className="fas fa-bolt text-destructive text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-4">Lightning Fast</h3>
            <p className="text-slate-600">Process images in seconds with our optimized AI models running on high-performance servers.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
              <i className="fas fa-shield-alt text-primary text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-4">Privacy First</h3>
            <p className="text-slate-600">Your images are processed securely and never stored on our servers longer than necessary.</p>
          </div>
        </div>

        {/* Feature Showcase */}
        <div className="bg-white rounded-3xl p-8 shadow-xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">See AI in Action</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                    <i className="fas fa-check text-white text-xs"></i>
                  </div>
                  <span className="text-slate-700">Intelligent object detection and selection</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                    <i className="fas fa-check text-white text-xs"></i>
                  </div>
                  <span className="text-slate-700">Advanced noise reduction algorithms</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                    <i className="fas fa-check text-white text-xs"></i>
                  </div>
                  <span className="text-slate-700">Real-time preview with instant feedback</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                    <i className="fas fa-check text-white text-xs"></i>
                  </div>
                  <span className="text-slate-700">Batch processing for multiple images</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                alt="AI processing interface" 
                className="rounded-2xl shadow-lg w-full" 
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
