import { Button } from "@/components/ui/button";

export function HeroSection() {
  const scrollToEditor = () => {
    document.getElementById('editor')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative py-20 bg-gradient-to-br from-slate-50 to-slate-100 overflow-hidden">
      <div className="absolute inset-0 bg-grid-slate-100 [mask-image:linear-gradient(0deg,white,rgba(255,255,255,0.6))]"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
            AI-Powered Image Editing
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent block">
              Made Simple
            </span>
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
            Transform your images with cutting-edge AI technology. No complex software needed - just upload, edit, and download stunning results in seconds.
          </p>
          <Button 
            onClick={scrollToEditor}
            size="lg"
            className="bg-primary text-white px-8 py-4 text-lg font-semibold hover:bg-primary/90 transform hover:scale-105 transition-all duration-200 shadow-lg"
          >
            Start Editing Now
          </Button>
        </div>

        {/* Sample Before/After Gallery */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-2xl p-6 shadow-lg image-hover-effect">
            <div className="mb-4">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Before AI enhancement" 
                className="w-full h-48 object-cover rounded-lg mb-2" 
              />
              <span className="text-sm text-slate-500">Before</span>
            </div>
            <div className="border-t pt-4">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="After AI enhancement" 
                className="w-full h-48 object-cover rounded-lg mb-2" 
              />
              <span className="text-sm text-slate-500">After AI Enhancement</span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg image-hover-effect">
            <div className="mb-4">
              <img 
                src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Landscape before enhancement" 
                className="w-full h-48 object-cover rounded-lg mb-2" 
              />
              <span className="text-sm text-slate-500">Before</span>
            </div>
            <div className="border-t pt-4">
              <img 
                src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Landscape after enhancement" 
                className="w-full h-48 object-cover rounded-lg mb-2" 
              />
              <span className="text-sm text-slate-500">After AI Enhancement</span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg image-hover-effect">
            <div className="mb-4">
              <img 
                src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Product with background" 
                className="w-full h-48 object-cover rounded-lg mb-2" 
              />
              <span className="text-sm text-slate-500">Before</span>
            </div>
            <div className="border-t pt-4">
              <img 
                src="https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Product with background removed" 
                className="w-full h-48 object-cover rounded-lg mb-2" 
              />
              <span className="text-sm text-slate-500">Background Removed</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
