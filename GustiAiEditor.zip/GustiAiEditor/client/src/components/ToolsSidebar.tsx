import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useImageProcessing } from "@/hooks/useImageProcessing";

export function ToolsSidebar() {
  const {
    brightness,
    contrast,
    saturation,
    setBrightness,
    setContrast,
    setSaturation,
    enhanceImage,
    removeBackground,
    colorCorrect,
    sharpenImage,
    isProcessing
  } = useImageProcessing();

  return (
    <div className="lg:col-span-1">
      <div className="bg-slate-50 rounded-2xl p-6 sticky top-8">
        <h3 className="font-semibold text-slate-900 mb-6">AI Tools</h3>
        
        {/* Enhancement Tools */}
        <div className="space-y-4 mb-8">
          <Button 
            onClick={enhanceImage}
            disabled={isProcessing}
            className="w-full justify-start space-x-3 p-3 bg-white hover:bg-slate-100 text-slate-900 border"
            variant="outline"
          >
            <i className="fas fa-sparkles text-primary"></i>
            <span>AI Enhance</span>
          </Button>
          
          <Button 
            onClick={removeBackground}
            disabled={isProcessing}
            className="w-full justify-start space-x-3 p-3 bg-white hover:bg-slate-100 text-slate-900 border"
            variant="outline"
          >
            <i className="fas fa-cut text-secondary"></i>
            <span>Remove Background</span>
          </Button>
          
          <Button 
            onClick={colorCorrect}
            disabled={isProcessing}
            className="w-full justify-start space-x-3 p-3 bg-white hover:bg-slate-100 text-slate-900 border"
            variant="outline"
          >
            <i className="fas fa-palette text-warning"></i>
            <span>Color Correction</span>
          </Button>
          
          <Button 
            onClick={sharpenImage}
            disabled={isProcessing}
            className="w-full justify-start space-x-3 p-3 bg-white hover:bg-slate-100 text-slate-900 border"
            variant="outline"
          >
            <i className="fas fa-adjust text-success"></i>
            <span>Sharpen</span>
          </Button>
        </div>

        {/* Manual Adjustments */}
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Brightness: {brightness}%
            </label>
            <Slider
              value={[brightness]}
              onValueChange={(value) => setBrightness(value[0])}
              max={200}
              min={0}
              step={1}
              className="w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Contrast: {contrast}%
            </label>
            <Slider
              value={[contrast]}
              onValueChange={(value) => setContrast(value[0])}
              max={200}
              min={0}
              step={1}
              className="w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Saturation: {saturation}%
            </label>
            <Slider
              value={[saturation]}
              onValueChange={(value) => setSaturation(value[0])}
              max={200}
              min={0}
              step={1}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
