import { useCallback, useState, useRef } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useImageProcessing } from "@/hooks/useImageProcessing";
import { useToast } from "@/hooks/use-toast";

export function CanvasArea() {
  const [showPreview, setShowPreview] = useState(false);
  const [showBefore, setShowBefore] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { 
    currentImage, 
    originalImage, 
    setCurrentImage, 
    setOriginalImage, 
    isProcessing, 
    brightness, 
    contrast, 
    saturation,
    resetImage,
    downloadImage 
  } = useImageProcessing();
  const { toast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setOriginalImage(imageUrl);
        setCurrentImage(imageUrl);
        setShowPreview(true);
      };
      reader.readAsDataURL(file);
    } else {
      toast({
        title: "Error",
        description: "Please select a valid image file.",
        variant: "destructive",
      });
    }
  }, [setCurrentImage, setOriginalImage, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.webp']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: false
  });

  const applyFilters = useCallback(() => {
    if (!currentImage || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      
      // Apply filters
      ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
      ctx.drawImage(img, 0, 0);
      
      // Update current image with filtered version
      const filteredDataUrl = canvas.toDataURL();
      setCurrentImage(filteredDataUrl);
    };
    img.src = originalImage || '';
  }, [brightness, contrast, saturation, currentImage, originalImage, setCurrentImage]);

  // Apply filters when values change
  useState(() => {
    if (originalImage) {
      applyFilters();
    }
  });

  const handleDownload = (format: 'jpg' | 'png' | 'webp') => {
    if (currentImage) {
      downloadImage(format);
    }
  };

  if (!showPreview) {
    return (
      <div className="lg:col-span-3">
        <div 
          {...getRootProps()} 
          className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer mb-8 transition-colors ${
            isDragActive ? 'border-primary bg-primary/5' : 'border-slate-300 hover:border-primary'
          }`}
        >
          <input {...getInputProps()} />
          <div className="mb-6">
            <img 
              src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150" 
              alt="Upload placeholder" 
              className="w-24 h-24 mx-auto rounded-lg opacity-50" 
            />
          </div>
          <h3 className="text-xl font-semibold text-slate-900 mb-2">Upload Your Image</h3>
          <p className="text-slate-600 mb-6">
            {isDragActive ? 'Drop your image here...' : 'Drag and drop your image here, or click to browse'}
          </p>
          <Button className="bg-primary text-white hover:bg-primary/90">
            <i className="fas fa-upload mr-2"></i>
            Choose File
          </Button>
          <div className="mt-4 text-sm text-slate-500">
            Supports JPG, PNG, WEBP • Max 10MB
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="lg:col-span-3">
      {/* Image Preview Area */}
      <div className="bg-slate-50 rounded-2xl p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-slate-900">Preview</h3>
          <div className="flex items-center space-x-2">
            <Button
              variant={showBefore ? "default" : "outline"}
              size="sm"
              onClick={() => setShowBefore(true)}
            >
              Before
            </Button>
            <Button
              variant={!showBefore ? "default" : "outline"}
              size="sm"
              onClick={() => setShowBefore(false)}
            >
              After
            </Button>
          </div>
        </div>
        
        {/* Image Container */}
        <div className="relative bg-white rounded-xl p-4 min-h-96 flex items-center justify-center">
          <img 
            src={showBefore ? (originalImage || '') : (currentImage || '')} 
            alt="Image preview" 
            className="max-w-full max-h-96 rounded-lg shadow-lg" 
          />
          
          {/* Processing Overlay */}
          {isProcessing && (
            <div className="absolute inset-0 bg-white/80 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-slate-600">AI is processing your image...</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Canvas for image processing (hidden) */}
      <canvas ref={canvasRef} style={{ display: 'none' }} />

      {/* Action Buttons */}
      <div className="flex items-center justify-between">
        <Button 
          variant="ghost"
          onClick={resetImage}
          className="flex items-center space-x-2 text-slate-600 hover:text-slate-900"
        >
          <i className="fas fa-undo"></i>
          <span>Reset</span>
        </Button>
        <div className="flex items-center space-x-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="flex items-center space-x-2 bg-success text-white hover:bg-success/90">
                <i className="fas fa-download"></i>
                <span>Download</span>
                <i className="fas fa-chevron-down ml-1 text-xs"></i>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleDownload('jpg')}>
                <i className="fas fa-file-image mr-2"></i>
                Download as JPG
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleDownload('png')}>
                <i className="fas fa-file-image mr-2"></i>
                Download as PNG
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleDownload('webp')}>
                <i className="fas fa-file-image mr-2"></i>
                Download as WebP
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button 
            variant="secondary"
            className="flex items-center space-x-2"
          >
            <i className="fas fa-share"></i>
            <span>Share</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
