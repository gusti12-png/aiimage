import { ToolsSidebar } from "./ToolsSidebar";
import { CanvasArea } from "./CanvasArea";

export function ImageEditor() {
  return (
    <section className="py-20 bg-white" id="editor">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Start Editing Your Images</h2>
          <p className="text-slate-600">Upload an image and watch our AI transform it instantly</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          <ToolsSidebar />
          <CanvasArea />
        </div>
      </div>
    </section>
  );
}
