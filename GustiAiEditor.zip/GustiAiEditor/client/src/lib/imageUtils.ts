export function dataURLtoBlob(dataURL: string): Blob {
  const arr = dataURL.split(',');
  const mime = arr[0].match(/:(.*?);/)?.[1] || '';
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  
  return new Blob([u8arr], { type: mime });
}

export function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export function validateImageFile(file: File): boolean {
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  const maxSize = 10 * 1024 * 1024; // 10MB
  
  if (!validTypes.includes(file.type)) {
    return false;
  }
  
  if (file.size > maxSize) {
    return false;
  }
  
  return true;
}

export function applyImageFilters(
  imageElement: HTMLImageElement,
  canvas: HTMLCanvasElement,
  filters: {
    brightness?: number;
    contrast?: number;
    saturation?: number;
  }
): string {
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  canvas.width = imageElement.naturalWidth;
  canvas.height = imageElement.naturalHeight;

  const { brightness = 100, contrast = 100, saturation = 100 } = filters;
  
  ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
  ctx.drawImage(imageElement, 0, 0);

  return canvas.toDataURL('image/jpeg', 0.9);
}
